package main

import (
	"fmt"
	"github.com/Tomas-vilte/GCPSteamAnalytics/functionGCP"
	"net/http"
)

func main() {
	http.HandleFunc("/test", functionGCP.OkResponse)
	http.HandleFunc("/dbgames", functionGCP.ProcessSteamDataAndSaveToStorage)

	fmt.Println("Server listening on :8080")
	http.ListenAndServe(":8080", nil)
}
